--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.ruang DROP CONSTRAINT ruang_pkey;
ALTER TABLE ONLY public.ruang DROP CONSTRAINT ruang_id_ruang_key;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_id_petugas_key;
ALTER TABLE ONLY public.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY public.peminjaman DROP CONSTRAINT peminjaman_id_peminjaman_key;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_id_level_key;
ALTER TABLE ONLY public.jenis DROP CONSTRAINT jenis_pkey;
ALTER TABLE ONLY public.jenis DROP CONSTRAINT jenis_id_jenis_key;
ALTER TABLE ONLY public.inventaris DROP CONSTRAINT inventaris_pkey;
ALTER TABLE ONLY public.inventaris DROP CONSTRAINT inventaris_id_inventaris_key;
ALTER TABLE ONLY public.detail_pinjam DROP CONSTRAINT detail_pinjam_pkey;
ALTER TABLE ONLY public.detail_pinjam DROP CONSTRAINT detail_pinjam_id_detail_pinjam_key;
DROP TABLE public.ruang;
DROP TABLE public.petugas;
DROP TABLE public.peminjaman;
DROP TABLE public.level;
DROP TABLE public.jenis;
DROP TABLE public.inventaris;
DROP TABLE public.detail_pinjam;
DROP TYPE public.status_peminjman;
DROP TYPE public.status_peminjaman;
DROP TYPE public.statu_peminjman;
DROP TYPE public.kondisi;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: kondisi; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE kondisi AS ENUM (
    'Sudah',
    'Belum'
);


ALTER TYPE kondisi OWNER TO postgres;

--
-- Name: statu_peminjman; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE statu_peminjman AS ENUM (
    'Lunas',
    'Belum'
);


ALTER TYPE statu_peminjman OWNER TO postgres;

--
-- Name: status_peminjaman; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status_peminjaman AS ENUM (
    'Lunas',
    'Belum'
);


ALTER TYPE status_peminjaman OWNER TO postgres;

--
-- Name: status_peminjman; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status_peminjman AS ENUM (
    'Lunas',
    'Belum'
);


ALTER TYPE status_peminjman OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_pinjam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_pinjam (
    id_detail_pinjam character varying NOT NULL,
    id_inventaris character varying(10),
    jumlah integer
);


ALTER TABLE detail_pinjam OWNER TO postgres;

--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventaris (
    id_inventaris character varying NOT NULL,
    nama character varying(50),
    kondisi kondisi,
    keterangan text,
    jumlah integer,
    id_jenis character varying(10),
    tanggal_register date,
    id_ruang character varying(10),
    kod_inventaris character varying(20),
    id_petugas character varying(10)
);


ALTER TABLE inventaris OWNER TO postgres;

--
-- Name: jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE jenis (
    id_jenis character varying NOT NULL,
    nama_jenis character varying(50),
    kode_jenis character varying(10),
    keterangan text
);


ALTER TABLE jenis OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level character varying NOT NULL,
    nama_level character varying(50)
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE peminjaman (
    id_peminjaman character varying NOT NULL,
    tanggal_pinjam date,
    tanggal_kembali date,
    status_peminjaman status_peminjaman,
    id_pegawai character varying(10)
);


ALTER TABLE peminjaman OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas character varying NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_petugas character varying(50),
    id_level character varying(10)
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE ruang (
    id_ruang character varying NOT NULL,
    nama_ruang character varying(50),
    kode_ruang character varying(10),
    keterangan text
);


ALTER TABLE ruang OWNER TO postgres;

--
-- Data for Name: detail_pinjam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM stdin;
\.
COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM '$$PATH$$/2863.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kod_inventaris, id_petugas) FROM stdin;
\.
COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kod_inventaris, id_petugas) FROM '$$PATH$$/2861.dat';

--
-- Data for Name: jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2860.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level) FROM stdin;
\.
COPY level (id_level, nama_level) FROM '$$PATH$$/2864.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2862.dat';

--
-- Data for Name: ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2866.dat';

--
-- Name: detail_pinjam detail_pinjam_id_detail_pinjam_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjam
    ADD CONSTRAINT detail_pinjam_id_detail_pinjam_key UNIQUE (id_detail_pinjam);


--
-- Name: detail_pinjam detail_pinjam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjam
    ADD CONSTRAINT detail_pinjam_pkey PRIMARY KEY (id_detail_pinjam);


--
-- Name: inventaris inventaris_id_inventaris_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris
    ADD CONSTRAINT inventaris_id_inventaris_key UNIQUE (id_inventaris);


--
-- Name: inventaris inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris
    ADD CONSTRAINT inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: jenis jenis_id_jenis_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis
    ADD CONSTRAINT jenis_id_jenis_key UNIQUE (id_jenis);


--
-- Name: jenis jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis
    ADD CONSTRAINT jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: level level_id_level_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_id_level_key UNIQUE (id_level);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: peminjaman peminjaman_id_peminjaman_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_id_peminjaman_key UNIQUE (id_peminjaman);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: petugas petugas_id_petugas_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_id_petugas_key UNIQUE (id_petugas);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: ruang ruang_id_ruang_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang
    ADD CONSTRAINT ruang_id_ruang_key UNIQUE (id_ruang);


--
-- Name: ruang ruang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang
    ADD CONSTRAINT ruang_pkey PRIMARY KEY (id_ruang);


--
-- PostgreSQL database dump complete
--

